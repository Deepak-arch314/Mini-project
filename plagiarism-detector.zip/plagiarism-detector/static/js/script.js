"use strict";

const $ = (id) => document.getElementById(id);
const MAX_FILE_BYTES = 1024 * 1024; // 1 MB per uploaded file

const SAMPLE_ORIGINAL =
  "Machine learning is used to predict rainfall using historical weather data. " +
  "Farmers can plan their crops better when forecasts are accurate. " +
  "Climate change makes rainfall patterns harder to predict.";
const SAMPLE_SUBMITTED =
  "Machine learning is used to predict rainfall using historical weather data. " +
  "Good forecasts help farmers choose what to grow. " +
  "Climate change makes rainfall patterns harder to predict.";

function showError(message) {
  const box = $("error-box");
  box.textContent = message;
  box.hidden = false;
  box.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
function clearError() { $("error-box").hidden = true; }

function countWords(text) {
  const words = text.trim().match(/\S+/g);
  return words ? words.length : 0;
}
function updateCounts() {
  $("original-count").textContent = countWords($("original").value) + " words";
  $("submitted-count").textContent = countWords($("submitted").value) + " words";
}

// ---- file upload (.txt only, read in the browser) ----
function setupUpload(fileInputId, textareaId) {
  $(fileInputId).addEventListener("change", (event) => {
    const file = event.target.files[0];
    event.target.value = ""; // allow re-selecting the same file
    if (!file) return;
    clearError();
    if (!file.name.toLowerCase().endsWith(".txt")) {
      showError("Only .txt files are supported. Please upload a .txt file or paste the text.");
      return;
    }
    if (file.size > MAX_FILE_BYTES) {
      showError("File is too large (maximum 1 MB).");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => { $(textareaId).value = reader.result; updateCounts(); };
    reader.onerror = () => showError("Could not read the file. Please try again.");
    reader.readAsText(file);
  });
}

// ---- rendering (textContent only -> user text can never inject HTML) ----
function renderSegments(container, segments) {
  container.replaceChildren();
  segments.forEach((seg) => {
    if (seg.match) {
      const mark = document.createElement("mark");
      mark.textContent = seg.text;
      container.appendChild(mark);
    } else {
      container.appendChild(document.createTextNode(seg.text));
    }
  });
}

function renderMatches(container, matches) {
  container.replaceChildren();
  if (!matches.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "No matching sections found.";
    container.appendChild(p);
    return;
  }
  matches.forEach((m, i) => {
    const card = document.createElement("div");
    card.className = "match";

    const tag = document.createElement("div");
    tag.className = "tag";
    tag.textContent = `Match ${i + 1} - ${m.word_count} words`;

    const p = document.createElement("p");
    const mark = document.createElement("mark");
    mark.textContent = m.text;
    p.appendChild(mark);

    card.append(tag, p);
    container.appendChild(card);
  });
}

function renderResult(r) {
  $("results").hidden = false;

  const verdict = $("verdict");
  verdict.className = "verdict " + (r.plagiarism_detected ? "bad" : "good");
  $("verdict-text").textContent = r.message;
  $("verdict-sub").textContent = r.plagiarism_detected
    ? `Similarity level: ${r.level}`
    : "The submitted text is mostly different from the original.";

  $("score-value").textContent = r.similarity + "%";
  const fill = $("meter-fill");
  fill.className = r.plagiarism_detected ? "bad" : "";
  fill.style.width = Math.min(r.similarity, 100) + "%";

  $("st-orig").textContent = r.stats.original_words;
  $("st-sub").textContent = r.stats.submitted_words;
  $("st-match").textContent = r.stats.matched_words;
  $("st-sections").textContent = r.stats.matched_sections;

  renderMatches($("matches"), r.matches);
  renderSegments($("hl-original"), r.original_segments);
  renderSegments($("hl-submitted"), r.submitted_segments);
  $("results").scrollIntoView({ behavior: "smooth" });
}

// ---- main action ----
async function checkPlagiarism() {
  clearError();
  const original = $("original").value;
  const submitted = $("submitted").value;

  if (!original.trim()) return showError("Please enter or upload the original text.");
  if (!submitted.trim()) return showError("Please enter or upload the submitted text.");

  const btn = $("check-btn");
  btn.disabled = true;
  btn.textContent = "Checking...";
  try {
    const response = await fetch("/api/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        original,
        submitted,
        algorithm: $("algorithm").value,
        min_words: $("min-words").value,
      }),
    });
    let data = null;
    try { data = await response.json(); } catch (_) { /* non-JSON response */ }
    if (!response.ok) {
      throw new Error((data && data.error) || `Server error (${response.status}).`);
    }
    renderResult(data);
  } catch (err) {
    const offline = err instanceof TypeError; // fetch failed: server not reachable
    showError(offline ? "Cannot reach the server. Is the Flask app running?" : err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Check Plagiarism";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  setupUpload("original-file", "original");
  setupUpload("submitted-file", "submitted");
  $("original").addEventListener("input", updateCounts);
  $("submitted").addEventListener("input", updateCounts);
  $("check-btn").addEventListener("click", checkPlagiarism);
  $("sample-btn").addEventListener("click", () => {
    $("original").value = SAMPLE_ORIGINAL;
    $("submitted").value = SAMPLE_SUBMITTED;
    updateCounts();
    clearError();
  });
  $("clear-btn").addEventListener("click", () => {
    $("original").value = "";
    $("submitted").value = "";
    $("results").hidden = true;
    updateCounts();
    clearError();
  });
});
