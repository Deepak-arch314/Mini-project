# Plagiarism Detection Using String Matching

Flask + HTML/CSS/JavaScript mini project.

## Run locally
    python -m venv venv
    venv\Scripts\activate          (Windows)   |   source venv/bin/activate   (Mac/Linux)
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000

## Run tests
    python -m unittest discover -s tests -v
